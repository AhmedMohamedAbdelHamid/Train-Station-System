
-- --------------------------------------------------------

--
-- Table structure for table `Ticket`
--

CREATE TABLE `Ticket` (
  `ID` int NOT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Trip_Name` varchar(50) DEFAULT NULL,
  `Schedule_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Ticket`:
--   `Schedule_ID`
--       `Schedule` -> `ID`
--

--
-- Dumping data for table `Ticket`
--

INSERT INTO `Ticket` (`ID`, `Price`, `Trip_Name`, `Schedule_ID`) VALUES
(1, '25.50', 'Morning Express', 1),
(2, '15.75', 'Afternoon Local', 2),
(3, '40.00', 'Evening Regional', 3),
(4, '30.25', 'Night InterCity', 4),
(5, '20.00', 'Early Bird Freight', 5);
