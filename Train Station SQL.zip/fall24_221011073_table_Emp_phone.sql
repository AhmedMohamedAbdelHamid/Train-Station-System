
-- --------------------------------------------------------

--
-- Table structure for table `Emp_phone`
--

CREATE TABLE `Emp_phone` (
  `ID` int NOT NULL,
  `Phone` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Emp_phone`:
--

--
-- Dumping data for table `Emp_phone`
--

INSERT INTO `Emp_phone` (`ID`, `Phone`) VALUES
(1, 321478965),
(2, 987412365),
(3, 854679124),
(4, 357951486),
(5, 200148956);
