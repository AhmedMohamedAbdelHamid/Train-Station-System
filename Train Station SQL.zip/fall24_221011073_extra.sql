
--
-- Indexes for dumped tables
--

--
-- Indexes for table `Booking`
--
ALTER TABLE `Booking`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Passenger_ID` (`Passenger_ID`);

--
-- Indexes for table `Employee`
--
ALTER TABLE `Employee`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Station_ID` (`Station_ID`);

--
-- Indexes for table `Emp_phone`
--
ALTER TABLE `Emp_phone`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Passenger`
--
ALTER TABLE `Passenger`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Review_ID` (`Review_ID`);

--
-- Indexes for table `Pass_Contact`
--
ALTER TABLE `Pass_Contact`
  ADD PRIMARY KEY (`ID`,`Phone`,`Gmail`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Place`
--
ALTER TABLE `Place`
  ADD PRIMARY KEY (`STATION_ID`,`TRAIN_ID`),
  ADD KEY `TRAIN_ID` (`TRAIN_ID`);

--
-- Indexes for table `Platform`
--
ALTER TABLE `Platform`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Station_id` (`Station_id`),
  ADD KEY `Schedule_id` (`Schedule_id`);

--
-- Indexes for table `Review`
--
ALTER TABLE `Review`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Schedule`
--
ALTER TABLE `Schedule`
  ADD PRIMARY KEY (`ID`,`State`,`ArriveTime`);

--
-- Indexes for table `Station`
--
ALTER TABLE `Station`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `STATION_ID` (`STATION_ID`);

--
-- Indexes for table `Ticket`
--
ALTER TABLE `Ticket`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Schedule_ID` (`Schedule_ID`);

--
-- Indexes for table `Train`
--
ALTER TABLE `Train`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Schedule_ID` (`Schedule_ID`);

--
-- Indexes for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD PRIMARY KEY (`Payment_ID`,`Booking_ID`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Booking`
--
ALTER TABLE `Booking`
  ADD CONSTRAINT `Booking_ibfk_1` FOREIGN KEY (`Passenger_ID`) REFERENCES `Passenger` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Employee`
--
ALTER TABLE `Employee`
  ADD CONSTRAINT `Employee_ibfk_1` FOREIGN KEY (`Station_ID`) REFERENCES `Station` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Passenger`
--
ALTER TABLE `Passenger`
  ADD CONSTRAINT `Passenger_ibfk_1` FOREIGN KEY (`Review_ID`) REFERENCES `Review` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Pass_Contact`
--
ALTER TABLE `Pass_Contact`
  ADD CONSTRAINT `Pass_Contact_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Passenger` (`ID`);

--
-- Constraints for table `Place`
--
ALTER TABLE `Place`
  ADD CONSTRAINT `Place_ibfk_1` FOREIGN KEY (`STATION_ID`) REFERENCES `Station` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `Place_ibfk_2` FOREIGN KEY (`TRAIN_ID`) REFERENCES `Train` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Platform`
--
ALTER TABLE `Platform`
  ADD CONSTRAINT `Platform_ibfk_1` FOREIGN KEY (`Station_id`) REFERENCES `Station` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `Platform_ibfk_2` FOREIGN KEY (`Schedule_id`) REFERENCES `Schedule` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Station`
--
ALTER TABLE `Station`
  ADD CONSTRAINT `Station_ibfk_1` FOREIGN KEY (`STATION_ID`) REFERENCES `Station` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Ticket`
--
ALTER TABLE `Ticket`
  ADD CONSTRAINT `Ticket_ibfk_1` FOREIGN KEY (`Schedule_ID`) REFERENCES `Schedule` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Train`
--
ALTER TABLE `Train`
  ADD CONSTRAINT `Train_ibfk_1` FOREIGN KEY (`Schedule_ID`) REFERENCES `Schedule` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `Transaction`
--
ALTER TABLE `Transaction`
  ADD CONSTRAINT `Transaction_ibfk_1` FOREIGN KEY (`Payment_ID`) REFERENCES `Payment` (`ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `Transaction_ibfk_2` FOREIGN KEY (`Booking_ID`) REFERENCES `Booking` (`ID`) ON DELETE CASCADE;
