
-- --------------------------------------------------------

--
-- Table structure for table `Schedule`
--

CREATE TABLE `Schedule` (
  `ID` int NOT NULL,
  `State` varchar(4) NOT NULL,
  `ArriveTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Schedule`:
--

--
-- Dumping data for table `Schedule`
--

INSERT INTO `Schedule` (`ID`, `State`, `ArriveTime`) VALUES
(1, 'GO', '08:00:00'),
(2, 'BACK', '09:15:00'),
(3, 'BACK', '10:30:00'),
(4, 'GO', '11:45:00'),
(5, 'GO', '13:00:00');
