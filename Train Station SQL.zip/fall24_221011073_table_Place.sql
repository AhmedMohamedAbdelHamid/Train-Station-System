
-- --------------------------------------------------------

--
-- Table structure for table `Place`
--

CREATE TABLE `Place` (
  `STATION_ID` int NOT NULL,
  `TRAIN_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Place`:
--   `STATION_ID`
--       `Station` -> `ID`
--   `TRAIN_ID`
--       `Train` -> `ID`
--

--
-- Dumping data for table `Place`
--

INSERT INTO `Place` (`STATION_ID`, `TRAIN_ID`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);
