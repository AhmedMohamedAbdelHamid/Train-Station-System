
-- --------------------------------------------------------

--
-- Table structure for table `Booking`
--

CREATE TABLE `Booking` (
  `ID` int NOT NULL,
  `Registration_Date` date DEFAULT NULL,
  `Passenger_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Booking`:
--   `Passenger_ID`
--       `Passenger` -> `ID`
--

--
-- Dumping data for table `Booking`
--

INSERT INTO `Booking` (`ID`, `Registration_Date`, `Passenger_ID`) VALUES
(1, '2023-12-02', 1),
(2, '2023-12-05', 2),
(3, '2023-12-03', 3),
(4, '2023-12-08', 4),
(5, '2023-12-12', 5);
