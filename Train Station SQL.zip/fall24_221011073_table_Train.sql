
-- --------------------------------------------------------

--
-- Table structure for table `Train`
--

CREATE TABLE `Train` (
  `ID` int NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Capacity` int DEFAULT NULL,
  `Made_From` varchar(50) DEFAULT NULL,
  `Production_Year` int DEFAULT NULL,
  `Schedule_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Train`:
--   `Schedule_ID`
--       `Schedule` -> `ID`
--

--
-- Dumping data for table `Train`
--

INSERT INTO `Train` (`ID`, `Name`, `Capacity`, `Made_From`, `Production_Year`, `Schedule_ID`) VALUES
(1, 'Lightning', 300, 'Steel', 2010, 1),
(2, 'Thunder', 200, 'Aluminum', 2012, 2),
(3, 'Storm', 250, 'Steel', 2015, 3),
(4, 'Tornado', 350, 'Composite', 2018, 4),
(5, 'Hurricane', 500, 'Steel', 2020, 5);
