
-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE `Payment` (
  `ID` int NOT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `Registration_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Payment`:
--

--
-- Dumping data for table `Payment`
--

INSERT INTO `Payment` (`ID`, `Amount`, `Registration_Date`) VALUES
(1, '100.00', '2023-12-01'),
(2, '250.30', '2023-12-02'),
(3, '140.00', '2023-12-03'),
(4, '230.10', '2023-12-04'),
(5, '84.60', '2023-12-05');
