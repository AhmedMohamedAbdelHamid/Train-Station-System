
-- --------------------------------------------------------

--
-- Table structure for table `Station`
--

CREATE TABLE `Station` (
  `ID` int NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Capacity` int DEFAULT NULL,
  `Government` varchar(50) DEFAULT NULL,
  `Region` varchar(50) DEFAULT NULL,
  `Street` varchar(100) DEFAULT NULL,
  `STATION_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Station`:
--   `STATION_ID`
--       `Station` -> `ID`
--

--
-- Dumping data for table `Station`
--

INSERT INTO `Station` (`ID`, `Name`, `Capacity`, `Government`, `Region`, `Street`, `STATION_ID`) VALUES
(1, 'Central Station', 10, 'Government1', 'Region1', 'Street1', 1),
(2, 'West Station', 8, 'Government2', 'Region2', 'Street2', 2),
(3, 'East Station', 7, 'Government3', 'Region3', 'Street3', 3),
(4, 'North Station', 5, 'Government4', 'Region4', 'Street4', 4),
(5, 'South Station', 9, 'Government5', 'Region5', 'Street5', 5);
