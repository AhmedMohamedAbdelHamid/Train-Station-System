
-- --------------------------------------------------------

--
-- Table structure for table `Pass_Contact`
--

CREATE TABLE `Pass_Contact` (
  `ID` int NOT NULL,
  `Phone` int NOT NULL,
  `Gmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Pass_Contact`:
--   `ID`
--       `Passenger` -> `ID`
--

--
-- Dumping data for table `Pass_Contact`
--

INSERT INTO `Pass_Contact` (`ID`, `Phone`, `Gmail`) VALUES
(1, 789456157, 'rat34@gmail.com'),
(2, 589641251, 'cat24@gmail.com'),
(3, 448962769, 'light2loop41@gmail.com'),
(4, 365477412, 'mail55sam34@gmail.com'),
(5, 400832170, 'warnotme@gmail.com');
