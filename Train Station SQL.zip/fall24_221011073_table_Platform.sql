
-- --------------------------------------------------------

--
-- Table structure for table `Platform`
--

CREATE TABLE `Platform` (
  `ID` int NOT NULL,
  `Number` int DEFAULT NULL,
  `Station_id` int DEFAULT NULL,
  `Schedule_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Platform`:
--   `Station_id`
--       `Station` -> `ID`
--   `Schedule_id`
--       `Schedule` -> `ID`
--

--
-- Dumping data for table `Platform`
--

INSERT INTO `Platform` (`ID`, `Number`, `Station_id`, `Schedule_id`) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 3, 3, 3),
(4, 4, 4, 4),
(5, 2, 5, 5);
