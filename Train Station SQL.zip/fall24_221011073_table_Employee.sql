
-- --------------------------------------------------------

--
-- Table structure for table `Employee`
--

CREATE TABLE `Employee` (
  `ID` int NOT NULL,
  `FName` varchar(50) DEFAULT NULL,
  `LName` varchar(50) DEFAULT NULL,
  `Salary` decimal(10,2) DEFAULT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Station_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Employee`:
--   `Station_ID`
--       `Station` -> `ID`
--

--
-- Dumping data for table `Employee`
--

INSERT INTO `Employee` (`ID`, `FName`, `LName`, `Salary`, `Position`, `DOB`, `Station_ID`) VALUES
(1, 'John', 'Doe', '50000.00', 'Conductor', '1985-04-12', 1),
(2, 'Jane', 'Smith', '55000.00', 'Engineer', '1990-08-25', 2),
(3, 'Alice', 'Brown', '45000.00', 'Ticket Inspector', '1982-11-16', 3),
(4, 'Bob', 'Jones', '60000.00', 'Manager', '1979-02-03', 4),
(5, 'Carol', 'White', '65000.00', 'Maintenance', '1995-07-30', 5);
