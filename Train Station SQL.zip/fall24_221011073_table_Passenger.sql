
-- --------------------------------------------------------

--
-- Table structure for table `Passenger`
--

CREATE TABLE `Passenger` (
  `ID` int NOT NULL,
  `FName` varchar(50) DEFAULT NULL,
  `LName` varchar(50) DEFAULT NULL,
  `Review_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Passenger`:
--   `Review_ID`
--       `Review` -> `ID`
--

--
-- Dumping data for table `Passenger`
--

INSERT INTO `Passenger` (`ID`, `FName`, `LName`, `Review_ID`) VALUES
(1, 'John', 'Doe', 1),
(2, 'Jane', 'Smith', 2),
(3, 'Alice', 'Brown', 3),
(4, 'Bob', 'Jones', 4),
(5, 'Carol', 'White', 5);
