
-- --------------------------------------------------------

--
-- Table structure for table `Transaction`
--

CREATE TABLE `Transaction` (
  `Payment_ID` int NOT NULL,
  `Booking_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Transaction`:
--   `Payment_ID`
--       `Payment` -> `ID`
--   `Booking_ID`
--       `Booking` -> `ID`
--

--
-- Dumping data for table `Transaction`
--

INSERT INTO `Transaction` (`Payment_ID`, `Booking_ID`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);
