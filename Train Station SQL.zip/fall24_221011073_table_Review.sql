
-- --------------------------------------------------------

--
-- Table structure for table `Review`
--

CREATE TABLE `Review` (
  `ID` int NOT NULL,
  `Rate` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- RELATIONSHIPS FOR TABLE `Review`:
--

--
-- Dumping data for table `Review`
--

INSERT INTO `Review` (`ID`, `Rate`) VALUES
(1, 2),
(2, 7),
(3, 8),
(4, 4),
(5, 10);
